package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ClassDAO;
import com.dao.StudentDAO;
import com.dao.SubjectDAO;
import com.dao.TeacherDAO;
import com.entity.Classes;
import com.entity.Students;

/**
 * Servlet implementation class DisplayServlet
 */
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		out.println("<div style = 'color: blue;'><h1>List of Class Logs</h1></div>");
		
		StudentDAO studentdao = new StudentDAO();
		ClassDAO classdao = new ClassDAO();
		SubjectDAO subjectdao = new SubjectDAO();
		TeacherDAO teacherdao = new TeacherDAO();
		
		
		
		List<Classes> listClasses = classdao.getAllClasses();
		List<String> subjectsnames;
		List<String> studentsnames;
		List<String> teachersclass;
		try {
			for(Classes s : listClasses) {
				out.println("class id is "+s.getClassId() + "\t" +", class name is "+ s.getClassName());
				
				out.print("<br>");
				subjectsnames = subjectdao.getAllStudents(s.getClassId());
				out.println("Subjects are: ");
				out.println(subjectsnames);
				out.print("<br>");
				studentsnames = studentdao.getAllStudents(s.getClassId());
				out.println("Students enrolled in this class are: ");
				out.println(studentsnames);
				
				out.print("<br>");
				teachersclass = teacherdao.getAllTeachers(s);
				out.print("Teachers assigned in this class are:");
				out.println(teachersclass);
				
				out.print("<br>");
				out.println("///end of row///");
				
				
				
				out.print("<br>");
				
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		//studentdao.getAllStudents();
		out.print("<br>");
		out.print("<br>");
		
		out.print("<a href = 'welcomepage.html' align = 'center'><h2>Back</h2></a>");
	}

}
