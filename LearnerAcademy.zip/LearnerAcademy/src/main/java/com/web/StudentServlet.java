package com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ClassDAO;
//import com.dao.ClassDAO;
import com.dao.StudentDAO;
import com.entity.Classes;
import com.entity.Students;


/**
 * Servlet implementation class StudentServlet
 */
//@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Students st = new Students();
		String sname = null;
		long contact;
		String city = null;
		int cid;
		String cname = null;
		
		sname = request.getParameter("name");
		contact = Long.parseLong(request.getParameter("contact"));
		city = request.getParameter("city");
		st.setStudentName(sname);
		st.setStudentContact(contact);
		st.setStudentCity(city);
		cid = Integer.parseInt(request.getParameter("classes2"));
		
		
		Classes cls = new Classes();
		
		switch(cid) {
			
			case 1:	cname = "Java FullStack Development";
					cls.setClassId(1);
					cls.setClassName(cname);
					cls.getStudent().add(st);
					st.setClasses(cls);
					break;
			case 2: cname = ".NET Development";
					cls.setClassId(2);
					cls.setClassName(cname);
					cls.getStudent().add(st);
					st.setClasses(cls);
					break;
			case 3: cname = "SAP";
					cls.setClassId(3);
					cls.setClassName(cname);
					cls.getStudent().add(st);
					st.setClasses(cls);
					break;
			case 4: cname = "Microsoft Azure";
					cls.setClassId(4);
					cls.setClassName(cname);
					cls.getStudent().add(st);
					st.setClasses(cls);
					break;
			case 5: cname = "CCNA";
					cls.setClassId(5);
					cls.setClassName(cname);
					cls.getStudent().add(st);
					st.setClasses(cls);
					break;
			case 6: cname = "Oracle Databases";
					cls.setClassId(6);
					cls.setClassName(cname);
					cls.getStudent().add(st);
					st.setClasses(cls);
					break;
		}
		
		 

		StudentDAO stdao = new StudentDAO();
		  stdao.insertStudentInDB(st);
		  
		 
		  
		  
		  
		  PrintWriter out = response.getWriter();
		  RequestDispatcher rd = request.getRequestDispatcher("welcomepage.html");
		 rd.include(request, response);
		 out.print("<div style = 'color : blue;' align = 'center'><h2>Student data entered successfully</h2></div>");
		 
		
	}

}
