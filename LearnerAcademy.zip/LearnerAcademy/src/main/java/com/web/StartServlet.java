package com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StartServlet
 */
public class StartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher rd; 
		PrintWriter out = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if(username.equalsIgnoreCase("Krishnendu") && password.equalsIgnoreCase("1234")) {
		//out.print("Welcome "+request.getParameter("username"));
		rd =  request.getRequestDispatcher("welcomepage.html");
		rd.forward(request, response);
		}
		else {
			rd= request.getRequestDispatcher("home.html");
			
			rd.include(request, response);
			out.print("<div align = 'center' style = 'color: red;'><h2>Sorry, You have entered wrong credential</h2></div>");
		}
	}

}
