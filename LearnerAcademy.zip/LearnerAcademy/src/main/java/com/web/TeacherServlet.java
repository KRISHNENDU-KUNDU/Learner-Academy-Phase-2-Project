package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ClassDAO;
import com.dao.SubjectDAO;
//import com.dao.ClassDAO;
import com.dao.TeacherDAO;
import com.entity.Classes;
import com.entity.Subjects;
import com.entity.Teachers;

/**
 * Servlet implementation class TeacherServlet
 * 
 */

//@WebServlet("/TeacherServlet")
public class TeacherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Classes cls = new Classes();
		int cid;
		String cname = null;
		int teacherId;
		
		
		cid = Integer.parseInt(request.getParameter("classes1"));
		
		switch(cid) {
			case 1:	cname = "Java FullStack Development";
					break;
			case 2: cname = ".NET Development";
					break;
			case 3: cname = "SAP";
					break;
			case 4: cname = "Microsoft Azure";
					break;
			case 5: cname = "CCNA";
					break;
			case 6: cname = "Oracle Databases";
					break;
		}
		 cls.setClassName(cname);
		 cls.setClassId(cid);
		 
		 Teachers tch = new Teachers();
		 TeacherDAO teacherdao = new TeacherDAO();
		 
		teacherId = Integer.parseInt(request.getParameter("teacher"));
		
		
		switch(teacherId) {
			case 1: 
					tch.setTeacherId(1);
					tch.setTeacherName("Krishnendu");
					
					
					tch.getTeacherclass().add(cls);
					
					cls.setTeachers(tch);
					teacherdao.insertTeacherInDB(tch);
					break;
			case 2: 
					tch.setTeacherId(2);
					tch.setTeacherName("Lucifer");
					
					tch.getTeacherclass().add(cls);
					
					cls.setTeachers(tch);
					teacherdao.insertTeacherInDB(tch);
					break;
			case 3: 
					tch.setTeacherId(3);
					tch.setTeacherName("Michael");
					
					tch.getTeacherclass().add(cls);
					
					cls.setTeachers(tch);
					teacherdao.insertTeacherInDB(tch);
					break;
			case 4: 
					tch.setTeacherId(4);
					tch.setTeacherName("Krish");
					
					tch.getTeacherclass().add(cls);
					
					cls.setTeachers(tch);
					teacherdao.insertTeacherInDB(tch);
					break;
			case 5: 
					tch.setTeacherId(5);
					tch.setTeacherName("Ashia");
					
					tch.getTeacherclass().add(cls);
					
					cls.setTeachers(tch);
					teacherdao.insertTeacherInDB(tch);
					break;
			case 6: 
					tch.setTeacherId(6);
					tch.setTeacherName("Shudhikkha");
					
					tch.getTeacherclass().add(cls);
					
					cls.setTeachers(tch);
					teacherdao.insertTeacherInDB(tch);
					break;
		}
		
		
		
		
		
		
		
		ClassDAO classesdao = new ClassDAO();
		
		classesdao.insertClassesInDB(cls);
		
		String[] subjectValue = null;
		
		subjectValue = request.getParameterValues("subject");
		
		
		Subjects sub = new Subjects();
		
		
		SubjectDAO subjectdao = new SubjectDAO();
		
		
		
		for(int i = 0;i < subjectValue.length;i++) {
			if(subjectValue[i].equals("1"))
			{
				
				sub.setSubjectId(1);
				sub.setSubjectName("Java");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("2"))
			{
				
				sub.setSubjectId(2);
				sub.setSubjectName("Hibernate");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("3"))
			{
				
				sub.setSubjectId(3);
				sub.setSubjectName("Maven");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("4"))
			{
				
				sub.setSubjectId(4);
				sub.setSubjectName("Devops");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("5"))
			{
				
				sub.setSubjectId(5);
				sub.setSubjectName("Azure");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			
			if(subjectValue[i].equals("6"))
			{
				
				sub.setSubjectId(6);
				sub.setSubjectName("C#");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("7"))
			{
				
				sub.setSubjectId(7);
				sub.setSubjectName(".NET");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("8"))
			{
				
				sub.setSubjectId(8);
				sub.setSubjectName("Sap Hana");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("9"))
			{
				
				sub.setSubjectId(9);
				sub.setSubjectName("Sap Net Weaver");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("10"))
			{
				
				sub.setSubjectId(10);
				sub.setSubjectName("SQL");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("11"))
			{
				
				sub.setSubjectId(11);
				sub.setSubjectName("Oracle");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
			if(subjectValue[i].equals("12"))
			{
				
				sub.setSubjectId(12);
				sub.setSubjectName("Computer Networking");
				cls.getClasssubject().add(sub);
				sub.setSubjectclasses(cls);
			    subjectdao.insertSubjectsInDB(sub);
			
			}
		}
		
		
		
		
		
		
		PrintWriter out = response.getWriter();
		
		RequestDispatcher rd = request.getRequestDispatcher("welcomepage.html");
		rd.include(request, response);
		out.print("<div style = 'color : red' align = 'center'><h2>Teacher Entry succesful</h2></div>");
		
		
		
		
		
	}

}
