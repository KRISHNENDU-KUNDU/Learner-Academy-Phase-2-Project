package com.dao;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.config.HibernateConfig;
import com.entity.Classes;
import com.entity.Students;
import com.entity.Teachers;

public class TeacherDAO {
	
	

	public void insertTeacherInDB(Teachers st) {
		Transaction transaction = null;
		Session dbSession = null;

		try {

			dbSession = HibernateConfig.getSessionFactory().openSession();

			// start the session

			transaction = dbSession.beginTransaction();

			// save the object of student in session

			dbSession.save(st);

			// commit the transaction

			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		} finally {
			dbSession.close();
		}
	}

	
	
	
	  public List<String> getAllTeachers(Classes cls) {
	  
		  List<String> newnames = new ArrayList<String>();
		 
	  
	  try { Session dbSession = HibernateConfig.getSessionFactory().openSession();
	  
		  //select * from student;
		  
		  List<Teachers> listTeachers = dbSession.createQuery("from Teachers").list();
		  
		  
		  for(Teachers s : listTeachers) {
		  
			  if(s.getTeacherId() == cls.getTeachers().getTeacherId()) {
				  
				  newnames.add(s.getTeacherName());
			  }
		  }
		  System.out.println(newnames);
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  
	  return newnames;
	 
}
	  
}
