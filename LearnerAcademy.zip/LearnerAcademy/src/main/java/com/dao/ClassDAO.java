package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.config.HibernateConfig;
import com.entity.Classes;
import com.entity.Teachers;


public class ClassDAO {
	
	public  void insertClassesInDB(Classes st) {
		Transaction transaction = null;
		Session dbSession = null;
		
		try {
			
			dbSession = HibernateConfig.getSessionFactory().openSession();
			
			//start the session
			
			transaction = dbSession.beginTransaction();
			
			//code to check if parameter is null
			
			
			
			//save the object of student in session
		
			dbSession.save(st);
			
			
			//commit the transaction
			
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}finally{
			dbSession.close();
		}
	}
	
	// Method to get the list of the names in database student
	
		
		  public List<Classes> getAllClasses() { 
			  
			  List<Classes> listClasses = null;
			  try { 
				  Session dbSession = HibernateConfig.getSessionFactory().openSession();
		  
		  //select * from student;
		  
		  listClasses = dbSession.createQuery("from Classes").list();
		  
		  } catch (Exception e) {
			  e.printStackTrace();
		}
			return listClasses;
			
		  }
		  
		  
}
