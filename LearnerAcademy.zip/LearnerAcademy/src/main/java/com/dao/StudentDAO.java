package com.dao;

import java.util.ArrayList;
import java.util.List;

//import java.util.List;


import org.hibernate.Session;
import org.hibernate.Transaction;

import com.config.HibernateConfig;
import com.entity.Students;

public class StudentDAO {
	
	
	
	

	public  void insertStudentInDB(Students st) {
		Transaction transaction = null;
		Session dbSession = null;
		
		try {
			
			dbSession = HibernateConfig.getSessionFactory().openSession();
			
			//start the session
			
			transaction = dbSession.beginTransaction();
			
			//save the object of student in session
			
			dbSession.save(st);
			
			
			//commit the transaction
			
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
			  finally{ dbSession.close(); }
			 
	}
	
	// Method to get the list of the names in database student
	
	
	  public List<String> getAllStudents(int clsid) { 
		  
		  List<String> newname = new ArrayList<String>();
				  
				  try { Session dbSession = HibernateConfig.getSessionFactory().openSession();
			  
			  //select * from student;
			  
						  List<Students> listStudents = dbSession.createQuery("from Students").list();
						
						  
						  for(Students s : listStudents) { 
								/*
								 * System.out.println(s.getStudentId() + "\t" + s.getStudentName() + "\t" +
								 * s.getStudentContact()+s.getStudentCity()); System.out.println();
								 */
							  if(s.getClasses().getClassId() == clsid) {
								  newname.add(s.getStudentName());
							  }
						  
						  }
			  
				  		}
				  catch (Exception e) { e.printStackTrace(); }
				return newname;
				
				 
				
		
		}
	 
}
