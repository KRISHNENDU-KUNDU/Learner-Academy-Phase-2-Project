package com.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.config.HibernateConfig;
import com.entity.Students;
import com.entity.Subjects;


public class SubjectDAO {
	
	
	
	
	public  void insertSubjectsInDB(Subjects st) {
		Transaction transaction = null;
		Session dbSession = null;
		
		try {
			
			dbSession = HibernateConfig.getSessionFactory().openSession();
			
			//start the session
			
			transaction = dbSession.beginTransaction();
			
			//save the object of student in session
			
			dbSession.save(st);
			
			//commit the transaction
			
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}finally{
			dbSession.close();
		}
	}
	
	
	public List<String> getAllStudents(int clsid) { 
		  
		List<String> newname = new ArrayList<String>();
		  
		  try { Session dbSession = HibernateConfig.getSessionFactory().openSession();
	  
	  //select * from student;
	  
				  List<Subjects> listSubjects = dbSession.createQuery("from Subjects").list();
				
				  
				  for(Subjects s : listSubjects) { 
						/*
						 * System.out.println(s.getStudentId() + "\t" + s.getStudentName() + "\t" +
						 * s.getStudentContact()+s.getStudentCity()); System.out.println();
						 */
					  if(s.getSubjectclasses().getClassId() == clsid) {
						  newname.add(s.getSubjectName());
						  
					  }
				  
				  }
	  
		  		}
		  catch (Exception e) { e.printStackTrace(); }
		return newname;
		
		 
		

}

}
