package com.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name = "Teachers")
@Table(name = "teacher")
public class Teachers {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "teacherId")
	private int teacherId;
	
	

	@Column(name = "teacherName")
	private String teacherName;
	
	
	
	@OneToMany(mappedBy = "teachers")
	private List<Classes> teacherclass = new ArrayList<Classes>();
	
	public Teachers() {
		
	}
	public Teachers(String teacherName)
		 {
		super();
		
		this.teacherName = teacherName;
		
	}

	

	public int getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(int teacherId) {
		this.teacherId = teacherId;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	
	

	public List<Classes> getTeacherclass() {
		return teacherclass;
	}

	public void setTeacherclass(List<Classes> teacherclass) {
		this.teacherclass = teacherclass;
	}
	
	
	
}
