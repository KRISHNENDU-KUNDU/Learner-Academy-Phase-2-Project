package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity(name = "Subjects")
@Table(name = "subjects")
public class Subjects {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "subjectId")
	private int subjectId;
	
	@Column(name = "subjectName")
	private String subjectName;
	
	@ManyToOne
	private Classes subjectclasses;
	
	public Subjects() {
		
	}

	public Subjects(String subjectName) {
		super();
		this.subjectName = subjectName;
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Classes getSubjectclasses() {
		return subjectclasses;
	}

	public void setSubjectclasses(Classes subjectclasses) {
		this.subjectclasses = subjectclasses;
	}
	
	
}
