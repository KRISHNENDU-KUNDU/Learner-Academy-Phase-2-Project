package com.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name = "Classes")
@Table(name = "classes")
public class Classes {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "classId")
	private int classId;
	
	@Column(name = "className")
	private String className;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Teachers teachers;
	
	@OneToMany(mappedBy = "subjectclasses")
	private List<Subjects> classsubject = new ArrayList<Subjects>();
	
	@OneToMany(mappedBy = "classes")
	private List<Students> student = new ArrayList<Students>();
	
	public Classes() {
		
	}

	public Classes(String className) {
		super();
		this.className = className;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Teachers getTeachers() {
		return teachers;
	}

	public void setTeachers(Teachers teachers) {
		this.teachers = teachers;
	}

	public List<Subjects> getClasssubject() {
		return classsubject;
	}

	public void setClasssubject(List<Subjects> classsubject) {
		this.classsubject = classsubject;
	}

	public List<Students> getStudent() {
		return student;
	}

	public void setStudent(List<Students> student) {
		this.student = student;
	}
	
	
	
}
