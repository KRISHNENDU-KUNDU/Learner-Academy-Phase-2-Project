package com.entity;
import javax.persistence.*;


@Entity(name = "Students")
@Table(name = "student")
public class Students {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "studentId")
	private int studentId;
	
	@Column(name = "studentName")
	private String studentName;
	
	@Column(name = "studentContact")
	private long studentContact;
	
	@Column(name = "studentCity")
	private String studentCity;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Classes classes;
	
	public Students() {
		
	}

	public Students(String studentName, long studentContact, String studentCity) {
		super();
		this.studentName = studentName;
		this.studentContact = studentContact;
		this.studentCity = studentCity;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public long getStudentContact() {
		return studentContact;
	}

	public void setStudentContact(long studentContact) {
		this.studentContact = studentContact;
	}

	public String getStudentCity() {
		return studentCity;
	}

	public void setStudentCity(String studentCity) {
		this.studentCity = studentCity;
	}

	public Classes getClasses() {
		return classes;
	}

	public void setClasses(Classes classes) {
		this.classes = classes;
	}
	
	

}
