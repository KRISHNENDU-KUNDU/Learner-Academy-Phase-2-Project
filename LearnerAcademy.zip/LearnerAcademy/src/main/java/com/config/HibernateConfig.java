package com.config;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import com.entity.Classes;
import com.entity.Students;
import com.entity.Subjects;
import com.entity.Teachers;


public class HibernateConfig {

private static SessionFactory sFactory;
	
	public static SessionFactory getSessionFactory() {
		
		if(sFactory == null) {
			try {
				Configuration cfg = new Configuration();
				
				//hibernate setting equivalent to hibernate.cfg.xml file
				
				Properties settings = new Properties();
				
				// Building the characteristics
				
				settings.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
				settings.put(Environment.URL, "jdbc:mysql://localhost:3306/ProjectBackend?useSSL=false&allowPublicKeyRetrieval=true");
				settings.put(Environment.USER, "root");
				settings.put(Environment.PASS, "12345678");
				settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL5Dialect");
				settings.put(Environment.SHOW_SQL, "true");
				settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");
				settings.put(Environment.HBM2DDL_AUTO, "create");
				//settings.put(Environment.HBM2DDL_AUTO, "update");
				
				//set the above properties as configuration
				
				cfg.setProperties(settings);
				
				// add the annotated class as configuration directory
				
				cfg.addAnnotatedClass(Students.class);
				cfg.addAnnotatedClass(Teachers.class);
				cfg.addAnnotatedClass(Subjects.class);
				cfg.addAnnotatedClass(Classes.class);
				
				// registering the services of the session using the configurations
				
				ServiceRegistry servReg = new StandardServiceRegistryBuilder().applySettings(cfg.getProperties()).build();
				
				//Building the service
				
				sFactory = cfg.buildSessionFactory(servReg);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		return sFactory;
	}
}
